package test4;

//����
class computer implements secondHand{
	String name;
	public computer(String name) {
		this.name = name;
	}
	@Override
	public String getName() {
		
		return name;
	}

}
