package test4;
//��Ʒ
class merchandise {
	secondHand s[];
	merchandise(secondHand s[]){
		this.s = s ;
	}
	void query(String name){
		for(secondHand ss:s){
			if(ss.getName().contains(name)==true){
				System.out.println(ss.getName());
			}
		}
	}
}
