package test4;

interface secondHand {
	String getName();
}
