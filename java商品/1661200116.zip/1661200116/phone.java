package test4;

//�ֻ�
class phone implements secondHand{
	String name;
	public phone(String name) {
		this.name = name;
	}
	@Override
	public String getName(){
		return name;
	}
}
