package ger;

public interface shangpin {
		String getName();
		double getPrice();
		
}
