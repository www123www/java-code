package ger;

public class shangdian {
	
	shangpin bo[]=new shangpin[30];	
	String dj;
	shangdian(shangpin[] bo,String dj){
		this.dj=dj;
		this.bo=bo;
	}

	
}
