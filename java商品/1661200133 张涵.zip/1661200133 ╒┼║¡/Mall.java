import java.awt.DisplayMode;
import java.util.ArrayList;
import java.util.List;

public class Mall {
	private List<Product> products;
	
	public Mall() {
		products =new ArrayList<>();
	}
	
	public void AddProduct(Product p)
	{
		if(p==null) return;
		products.add(p);
	}
	
	public void removeProduct(Product p)
	{
		if(p==null) return;
		products.remove(p);
	}
	
	public void displayAll() {
		for (int i = 0; i < products.size(); i++) {
			System.out.print((i+1)+".");
			displayProduct(products.get(i));
		}
	}
	
	public void displayProduct( Product p) {
		System.out.print(p.get_Name()+"   ");
		System.out.print("�۸�:"+p.get_Price()+"   ");
		System.out.println(p.get_Information());
	}
	
	public void  findProduct_By_Pname(String Pname) {
		List<Product> temps =new ArrayList<>();
		for (int i = 0; i < products.size(); i++) {
			if(contains(products.get(i),Pname))
				temps.add(products.get(i));
		}
		if(temps.size()!=0)
		{
			System.out.println(Pname+" ���ҽ�����£�");
			for (int i = 0; i < temps.size(); i++) {
				displayProduct(temps.get(i));
			}
		}
		else
		{
			System.out.println("δ���ҵ��κ��й�   ��"+Pname+"�� �ļ�¼");
		}
	}
	
	public boolean contains(Product p,String Pname)
	{
		if(p.get_Name().indexOf(Pname)!=-1)
		return true;
		return false;
		
	}
}
