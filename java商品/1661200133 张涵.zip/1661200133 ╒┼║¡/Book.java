
public class Book implements Product{
	public String TypeName="�鼮";
	public String Bname;
	public String BNewLV;
	public String BInf;
	public String Bauthor;
	public int BPageNumber;
	public float Bprice;
	
	public Book( String Bname,String BNewLV,String BInf,String Bauthor,int BPageNumber,float Bprice) {
		// TODO Auto-generated constructor stub

		this.Bname=Bname;
		this.BNewLV=BNewLV;
		this.BInf = BInf;
		this.Bauthor=Bauthor;
		this.BPageNumber=BPageNumber;
		this.Bprice=Bprice;
	}
	@Override
	public String get_Name() {
		// TODO Auto-generated method stub
		return Bname;
	}

	@Override
	public String get_Information() {
		// TODO Auto-generated method stub
		return TypeName+"_"+BNewLV+"����       "+"����:"+Bauthor+"   ҳ��:"+BPageNumber+"   "+BInf;
	}

	@Override
	public float get_Price() {
		// TODO Auto-generated method stub
		return Bprice;
	}

}
