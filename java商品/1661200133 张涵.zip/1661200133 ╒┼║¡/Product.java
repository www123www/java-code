
public interface Product {
	public String get_Name();
	public String get_Information();
	public float get_Price();
}
