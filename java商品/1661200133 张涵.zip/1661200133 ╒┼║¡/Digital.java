
public class Digital implements Product{
	public String TypeName="�����Ʒ";
	public String Dname;
	public String DNewLV;
	public String DInf;
	public float Dprice;
	public Digital( String Dname,String DNewLV,String DInf,float Dprice) {
		// TODO Auto-generated constructor stub
	
		this.Dname=Dname;
		this.DNewLV=DNewLV;
		this.DInf = DInf;
		this.Dprice=Dprice;
	}
	@Override
	public String get_Name() {
		// TODO Auto-generated method stub
		return Dname;
	}

	@Override
	public String get_Information() {
		// TODO Auto-generated method stub
		return  TypeName+"_"+DNewLV+"����,"+DInf;
	}

	@Override
	public float get_Price() {
		// TODO Auto-generated method stub
		return Dprice;
	}
	
}
