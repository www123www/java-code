package T;

public class Rabbit extends Animal {

	public Rabbit(String AnimalNmae, int Lv) {
		super(AnimalNmae, Lv);
		// TODO Auto-generated constructor stub
	}
	public Rabbit(String AnimalNmae,int Lv,int t) {
		super(AnimalNmae, Lv,t);
	}
}
