package T;

public class Wolf extends Animal {

	public Wolf(String AnimalNmae, int Lv) {
		super(AnimalNmae, Lv);
		// TODO Auto-generated constructor stub
	}
	public Wolf(String AnimalNmae,int Lv,int t) {
		super(AnimalNmae, Lv,t);
	}
}
