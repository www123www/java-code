public class Animal {
    int x,y;

    void move(int d){
        switch (d){
            case 1:
                if (x>0) {
                    x -= 1;
                }else {
                    System.out.println("超过边界");
                }
                break;
            case 2:
                if (x < 10) {
                    x += 1;
                } else {
                    System.out.println("超过边界");
                }
                break;
            case 3:
                if (y > 0) {
                    y -= 1;
                } else {
                    System.out.println("超过边界");
                }
                break;
            case 4:
                if (y < 10) {
                    y += 1;
                } else {
                    System.out.println("超过边界");
                }
                break;
        }
        if (d==1){

        }
        if (d==2){

        }
        if (d==3){

        }
        if (d==4){

        }
    }
    void die(){
        x=-1;
        y=-1;
    }
}
class Lion extends Animal{

    Lion(){
        x=3;
        y=4;
    }
}
class Wolf extends Animal{
    Wolf(){
        x=5;
        y=6;
    }
}
class  Rabbit extends Animal{
    Rabbit(){
        x=7;
        y=8;
    }
}