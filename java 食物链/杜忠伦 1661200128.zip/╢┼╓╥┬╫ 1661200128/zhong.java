public class zhong {
    Animal animal[]={new Lion(),new Rabbit(),new Wolf()};


    void compare(){
        if (animal[0].x==animal[1].x&&animal[0].y==animal[1].y){
            animal[1].die();
        }
        if (animal[1].x==animal[2].x&&animal[1].y==animal[2].y){
            animal[2].die();
        }
        if (animal[1].x==animal[2].x&&animal[1].y==animal[2].y){
            animal[2].die();
        }
    }

    void show(){
        compare();
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                if (animal[0].x==i&&animal[0].y==j){
                    System.out.print("L");
                }else if (animal[1].x==i&&animal[1].y==j){
                    System.out.print("W");
                }else if (animal[2].x==i&&animal[2].y==j){
                    System.out.print("R");
                }else {
                    System.out.print("_");
                }
            }
            System.out.println();
        }
    }

    void choice(int a, int d){
        if (a==1){
            animal[0].move(d);
        }
        if (a==2){
            animal[1].move(d);
        }
        if (a == 3) {
            animal[2].move(d);
        }
    }
}
