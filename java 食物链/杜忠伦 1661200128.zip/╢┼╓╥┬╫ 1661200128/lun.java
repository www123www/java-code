﻿import java.util.Scanner;

public class lun {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        Eat eat=new Eat();
        eat.show();
        int i;
        int direction;
        System.out.println("输入移动的动物 a.狮子 b.狼 c.兔子 ");
        i=scanner.nextInt();
        if (i==0){
            return;
        }
        System.out.println("移动的方向 a.上 b.下 c.左 d.右:");
        direction=scanner.nextInt();
        while (true){
            eat.choice(i,direction);
            eat.show();
            System.out.println("输入控制的动物 a.狮子 b.狼 c.兔子 d.结束:");
            i=scanner.nextInt();
            System.out.println("移动的方向 a.上 b.下 c.左 d.右:");
            direction=scanner.nextInt();
        }
    }
}
