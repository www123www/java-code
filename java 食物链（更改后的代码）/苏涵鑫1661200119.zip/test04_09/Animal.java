package test04_09;

abstract class Animal{
	String name;
	int x,y,lv;
	Animal(String name,int x,int y,int lv){
		this.name = name;
		this.x = x;
		this.lv = lv;
		this.y = y;
	}
	public abstract void remove(int x,int y);
}
