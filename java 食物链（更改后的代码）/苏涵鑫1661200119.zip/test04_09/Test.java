package test04_09;

import java.util.Random;

public class Test {
	public static void main(String[] args) {
		Rule rule = new Rule();
		Animal[] b = {new Lion("Lion", 6, 6, 3),new Wolf("Wolf", 4, 4, 2),new Cat("Cat", 2, 2, 1)};
		rule.a = b;
		int count = rule.a.length;

		Random r = new Random();
		while(count!=1) {
			boolean f = rule.test();
			if(f==true) {
				count--;
			}
		}
			
		
	}
}
