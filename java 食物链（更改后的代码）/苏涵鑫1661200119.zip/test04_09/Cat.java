package test04_09;

import java.util.Random;

class Cat  extends Animal{

	Cat(String name, int x, int y, int lv) {
		super(name, x, y, lv);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void remove(int x,int y){
		Random r = new Random();
		if(x==-1||x==1){
			y=0;
		}else{
			int i=0;
			while(i==0){
				y = r.nextInt(3)-1;
				if(y!=0){
					i=-1;
				}
			}
		}
		if(this.lv!=0){
			if(this.x+x<0||this.x+x>10||this.y+y<0||this.y+y>10) {
				System.out.println(this.name+"ײǽ�˻ع�����أ�");
				this.x = 2;
				this.y = 2;
			}else {
				this.x +=x;
				this.y +=y;
			}
		}
	}

}
