package test04_09;

import java.util.Random;

public class Rule {
	Animal a[];
	public boolean test(){
		Random r = new Random();
		for(int i=0;i<a.length;i++){
			if(a[i] instanceof Lion){
				a[i].remove(r.nextInt(5)-2, 0);
			}else if(a[i] instanceof Wolf){
				a[i].remove(r.nextInt(5)-2, 0);
			}else if(a[i] instanceof Cat){
				a[i].remove(r.nextInt(3)-1, 0);
			}
			if(a[i].lv!=0) {
				System.out.println("name:"+a[i].name+"\nx:"+a[i].x+"\ty:"+a[i].y);
			}
		}
		return booleanFeed();
	}
	
	public boolean booleanFeed(){
		for(Animal animal:a) {
			for(int i=0;i<a.length;i++) {
				if(a[i].lv!=0&&!animal.name.equalsIgnoreCase(a[i].name)){
				if(animal.x==a[i].x&&animal.y==a[i].y) {
					if(animal.lv>a[i].lv) {
						System.out.println(animal.name+"�Ե���"+a[i].name);
						a[i].lv = 0;
						return true;
					}
				  }
				}
			}
		}
		return false;
	}
}
