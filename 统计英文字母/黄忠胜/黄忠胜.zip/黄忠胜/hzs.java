﻿import java.util.Scanner;

public class Haha {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("输入：");
        String str = sc.nextLine();
        char chs[] = str.toCharArray();


        for (char ch = 'a'; ch < 'z'; ch++) {
            int count = 0;
            for (int i = 0; i < chs.length; i++)
                if (ch == chs[i]) {
                    count++;
                }
            if (count != 0) {
                System.out.println(ch + "有" + count + "个");
            }
        }

    }
}

